import numpy as np
import labscript_utils.h5_lock
import h5py
from blacs.tab_base_classes import Worker
from labscript import LabscriptError

import sys
import os
import logging
import time
from zprocess import RichStreamHandler
import zprocess
import inspect

class BlueBoxWorker(Worker):
    # additional properties passed down by the initialise_workers() method in blacs_tabs.py
    # - build_path
    # - vivado_path
    # - startup_script
    # - dac_config
    # - ip
    # - udp
    # - frequency_scale_factor
    # - amplitude_scale_factor
    # - phase_scale_factor
    # - num_instances
    # - channels_per_instance
    def init(self):


        self.logger = logging.getLogger("bluebox")
        self.logger.setLevel(logging.DEBUG)

        # Prevent duplicate handlers if this code runs more than once
        if not self.logger.handlers:
            self.logger.addHandler(RichStreamHandler())

        # Now use it in your code
        self.logger.error("Worker started")

        #sys.path.append(os.path.join(os.path.dirname(__file__), self.build_path))
        from fvseei.lbus_access import lbus_access
        from fvseei.lbus_csr import Csr_Lbus
        from fvseei.multi_tone_controller import MultiToneController
        print(inspect.getfile(MultiToneController))
        print(inspect.getfile(lbus_access))
        print(inspect.getfile(Csr_Lbus))
        #print(fvseei.multi_tone_controller.__file__)


        # cmd1 = self.vivado_path
        # cmd2 = r".venv\Scripts\activate.bat" #activate virtual environment
        # cmd3 = "python " + self.startup_script
        # cmd4 = self.dac_config
        # os.system(cmd1+";"+cmd2+";"+cmd3+";"+cmd4)

        chip = lbus_access(self.ip, timeout=1.02, port=self.udp, allow_burst=False)
        self.csr = Csr_Lbus(chip)

        self.tone_controllers = []
        for i in range(self.num_instances):
            controller = MultiToneController(self.csr, dds_index=i)
            self.tone_controllers.append(controller)
            self.logger.info(f"Initialized MultiToneController for DDS instance {i}")

    def freq_to_lsb(self, freq): #frequency in MHz

        #if freq > 270:
            #raise LabscriptError("Too close to the Nyquist frequency. Please enter a frequency less than or equal to 270 MHz.")
        freq = np.round(self.frequency_scale_factor*freq).astype(int) #rounds off converted lsb to nearest integer
        return freq

    def amp_to_lsb(self, amp): #max amplitude = 1

        if amp > 1:
            raise LabscriptError("Max amplitude is 1. Please enter an amplitude less than or equal to 1.")
        amp = np.round(self.amplitude_scale_factor*amp).astype(int)
        return amp

    def phase_to_lsb(self, phase): #phase in degrees

        phase = np.round(self.phase_scale_factor*phase).astype(int) 
        return phase

    def write_register(self, instance, channel, value, csr, register_type):
        method_name = f"ddsctrl{instance}_{register_type}_{channel}_write"
        method = getattr(csr, method_name, None)
        if method:
            method(value)
        else:
            print(f"Method {method_name} not found.")

    def transition_to_buffered(self,device_name,h5file,initial_values,fresh):
        from fvseei.move_tone_sequencer_example import (reset_synthesizer, clear_sequencer_memory, write_sequencer_command, debug_sequencer_state)
        self.initial_values = initial_values
        self.final_values = {}

        
        # reset_synthesizer(self.csr, active_channels={0: list(range(9))})
        # clear_sequencer_memory(self.csr, num_slots=64)
        with h5py.File(h5file, 'r') as hdf5_file:
            group = hdf5_file['/devices/'+device_name]

            active_channels = {}

            for i,dset in enumerate(group.values()): #enumerate these two loops to then pass the correct channel and instance number i and channel number j into write_register
                active_list = []

                for j,outputs in enumerate(dset):
                    freq, amp, phase, gate, rampdur, rampdel, rampfreq = outputs

                    if gate == 1:
                        active_list.append(j)

                active_channels[i] = active_list

            reset_synthesizer(self.csr, active_channels=active_channels)

            for i,dset in enumerate(group.values()): #enumerate these two loops to then pass the correct channel and instance number i and channel number j into write_register
                controller = self.tone_controllers[i]
                
                controller.reset()

                has_moves = False

                for j,outputs in enumerate(dset):
                    freq, amp, phase, gate, rampdur, rampdel, rampfreq = outputs

                    if gate == 1:
                        controller.set_tone(channel=j,freq_mhz=freq,amplitude=amp,phase_deg=phase)

                    if rampdur and rampdel and rampfreq:
                        
                        has_moves = True

                        controller.move_tone(
                            channel=j,
                            target_freq=rampfreq,
                            duration=rampdur,
                            delay=rampdel
                        )

                        print(f"  Queued: Tone {j} → {rampfreq} MHz (start at t={rampdel:.1f}s) with duration {rampdur}")


                    #dictionary of dictionaries, for now we just integrate the instance 0 channel 0 DDS in with the GUI
                    if i==0 and j==0:
                        final_values = {'dds 0':{}} #should match the name of the corresponding output objects placed in the dds BLACS UI widgets, pushes these values into the widgets
                        
                        final_values['dds 0']['freq'] = np.round(freq)
                        final_values['dds 0']['amp'] = np.round(amp)
                        final_values['dds 0']['phase'] = np.round(phase)
                        final_values['dds 0']['gate'] = gate

                if has_moves:

                    print(controller.moves)

                    debug_sequencer_state(self.csr)

                    controller._build_sequencer_commands()

                    # Configure presets in hardware
                    controller._configure_presets()

                    # Clear sequencer memory
                    print("\n=== Programming sequencer ===")
                    clear_sequencer_memory(self.csr, num_slots=max(16, len(controller.seq_commands) + 1))

                    # Write commands
                    for slot, (time_sec, cmd) in enumerate(controller.seq_commands):
                        write_sequencer_command(self.csr, slot, time_sec, cmd)
                        print(f"  Slot {slot}: t={time_sec:.1f}s")

                    # Calculate total duration (last command + max ramp duration + margin)
                    if controller.seq_commands:
                        last_time = controller.seq_commands[-1][0]
                        max_duration = max(duration for _, _, _, duration, _ in controller.moves)
                        total_duration = last_time + max_duration + 1.0
                    else:
                        total_duration = 2.0

                    # Set sequencer stopafter
                    stopafter_cycles = int(total_duration * 153.6e6)
                    self.csr.seq_stopafter_write(stopafter_cycles)
                    print(f"\nTotal duration: {total_duration:.1f}s ({stopafter_cycles} cycles)")

                    self.csr.status_clear_counters_write(1)
                    time.sleep(0.01)

                

                getattr(self.csr, f"{controller.prefix}_syncddsstatic_write")(1)

                        



            method = getattr(self.csr, "dac_global_clr_write", None)
            method(0)  
 
        return final_values

    def check_remote_values(self): #when we add more channels, will have to loop through the datasets (instance) and dataset elements (channels) by reading the shot h5 file, just like in transition_to_buffered()

        results = {'dds 0':{}}

        method = getattr(self.csr, "ddsctrl0_ftw_0_read", None)
        freq = method() #in lsb
        freq = np.round(freq/self.frequency_scale_factor)
        method = getattr(self.csr, "ddsctrl0_atw_0_read", None)
        amp = method()
        amp = np.round(amp/self.amplitude_scale_factor)
        method = getattr(self.csr, "ddsctrl0_ptw_0_read", None)
        phase = method()
        phase = np.round(phase/self.phase_scale_factor)
        method = getattr(self.csr, "ddsctrl0_clr_0_read", None)
        gate = 1-method()

        results['dds 0']['freq'] = freq
        results['dds 0']['amp'] = amp
        results['dds 0']['phase'] = phase
        results['dds 0']['gate'] = gate

        #can try converting into natural units but only if we also "reconvert" the lsb values in transition_to_buffered()

        return results

    def program_manual(self,front_panel_values): #must modify for more channels and add for loops to loop through front_panel_values, don't know yet if we're gonna have 64*4 separate DDS widgets or how to display them
        freq = front_panel_values['dds 0']['freq']
        amp = front_panel_values['dds 0']['amp']
        phase = front_panel_values['dds 0']['phase']
        gate = front_panel_values['dds 0']['gate']
                                        # in the future we want the GUI values to be in natural units?
        controller = self.tone_controllers[0]

        method = getattr(self.csr, "dac_global_clr_write", None)
        method(1)
        if gate == 1:
            controller.set_tone(0,freq,amp,phase)

        method = getattr(self.csr, "ddsctrl0_syncddsstatic_write", None)
        method(1)
        method = getattr(self.csr, "dac_global_clr_write", None)
        method(0)  

        return self.check_remote_values()

    def abort_transition_to_buffered(self):
        return self.transition_to_manual(True)
        
    def abort_buffered(self):
        return self.transition_to_manual(True)
    
    def transition_to_manual(self,abort = False):
        if abort:
            # If we're aborting the run, reset to original value
            self.program_manual(self.initial_values)
        # If we're not aborting the run, stick with buffered value. Nothing to do really!
        # return the current values in the device
        return True