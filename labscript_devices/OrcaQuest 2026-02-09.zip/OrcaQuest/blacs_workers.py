import numpy as np
import labscript_utils.h5_lock
import labscript_utils.properties
import h5py
from blacs.tab_base_classes import Worker
from .dcam import *
from .dcamapi4 import *
import zmq
import threading
import logging
from multiprocessing import shared_memory
from zprocess import RichStreamHandler
import json
import os
import matplotlib.pyplot as plt
import time
from time import perf_counter

from labscript_utils.ls_zprocess import Context

class OrcaQuestWorker(Worker):
    # additional properties passed down by the initialise_workers() method in blacs_tabs.py
    # - parent_host
    # - trigger_source
    # - attr_dict
    # - rearrange_active
    # - stop_acquisition_timeout
    # - image_receiver_port

    def init(self):

        self.logger = logging.getLogger("bluebox")
        self.logger.setLevel(logging.DEBUG)

        # Prevent duplicate handlers if this code runs more than once
        if not self.logger.handlers:
            self.logger.addHandler(RichStreamHandler())

        # Now use it in your code
        self.logger.error("Worker started")

        self.image_shape = [2304,4096]
        self.image_dtype = "uint16"

        if Dcamapi.init():
            device_index = 0 #hardcoded Hamamatsu device index, but can make into a connection table property in the future if we start using more than one Hamamatsu device
            self.dcam = Dcam(device_index)
            if self.dcam.dev_open():
                self.dcam.prop_setvalue(DCAM_IDPROP.TRIGGERSOURCE, self.trigger_source)
                for key in self.attr_dict:
                    print(key, self.attr_dict[key])
                    self.dcam.prop_setvalue(getattr(DCAM_IDPROP,key,None), self.attr_dict[key])
                    if key == "SUBARRAYVSIZE":
                        self.image_shape[0] = self.attr_dict[key]
                    if key == "SUBARRAYHSIZE":
                        self.image_shape[1] = self.attr_dict[key]
                    if key == "BITSPERCHANNEL":
                        if self.attr_dict[key] == 16 or 12:
                            self.image_dtype = "uint16"
                        if self.attr_dict[key] == 8:
                            self.image_dtype = "uint8"
            else:
                self.logger.error('-NG: Dcam.dev_open() fails with error {}'.format(self.dcam.lasterr()))
        else:
            self.logger.error('-NG: Dcamapi.init() fails with error {}'.format(Dcamapi.lasterr()))

        self.images = []
        self.n_images = None

        self.exposures = None
        self.acquisition_thread = None
        self.h5_filepath = None

        self.fetch_image_finished = threading.Event()

        self.zmq_context = zmq.Context()

        self.image_socket = self.zmq_context.socket(zmq.REQ)
        self.image_socket.connect(
            f'tcp://{self.parent_host}:{self.image_receiver_port}'
        )
        if self.rearrange_active:
            self.shm_frame = shared_memory.SharedMemory(create=True, size = 2*2304*4096, name = "camera_frame") #allocates shared memory (equal to the number of bytes needed to store a single OrcaQuest camera image at full resolution and dynamic range) for the rearrangment image, to be accessed by external rearrangement script
            self.shm_img = np.ndarray(tuple(self.image_shape), dtype=self.image_dtype, buffer=self.shm_frame.buf) #creates an empty array in the above shared memory to hold the image

            self.shm_flag = shared_memory.SharedMemory(create=True, size = 8, name = "img_flag") #allocates shared memory for a flag that updates when a new image is sent over
            self.shm_count = np.ndarray((1,), dtype=np.int64, buffer=self.shm_flag.buf) #creates an empty array (1D array with one element, which is an int64 counter) in the above shared memory to hold the flag
            self.shm_count[0] = -1

            with open("shm.json", "w") as f:
                json.dump([self.image_shape, self.image_dtype], f)
                self.logger.error("Saving json")

        self.for_rearrange = []

    def fetch_n_images(self):
        poll_timeout = 1 #polls in intervals of 1 ms, could this be longer?

        if self.dcam.cap_snapshot():
            for i in range(self.n_images):
                self.logger.error('looking for image'+str(i))
                self.logger.error('status 0: {}'.format(self.dcam.cap_status()))
                while True:
                    if self.dcam.wait_capevent_frameready(poll_timeout): #wait until the camera detects a capture event and then pulls from the buffer during the downtime of the main thread performing shot execution
                        data = self.dcam.buf_getlastframedata() #data in the form of 2d numpy array
                        print(self.for_rearrange)
                        if self.for_rearrange[i]:

                            self.logger.error(data.shape)
                            self.logger.error(data.dtype)
                            self.logger.error(data.nbytes)
                            print(data)

                            self.shm_img[:] = data #saves image to the array that lives in the correct shared memory (overwrites previous image in that array)

                            print(self.shm_img)
                            self.shm_count[0] = i #updates "new image" flag in the correct shared memory

                            print("flag updated to " + str(self.shm_count[0]))


                        self.logger.error('new capture acquired')
                        break
                    else:
                        dcamerr = self.dcam.lasterr()
                        if dcamerr.is_timeout():
                            continue
                        else:
                            self.logger.error('-NG: Dcam.wait_event() fails with error {}'.format(dcamerr))

                self.images.append(data)    
        else:
            print('-NG: Dcam.cap_start() fails with error {}'.format(self.dcam.lasterr()))

        self.fetch_image_finished.set() #for fetch_n_images(), call this method at the very end after the loop has fully completed and self.images is fully populated

    def _send_image_to_parent(self, image):
        """Send the image to the GUI to display. This will block if the parent process
        is lagging behind in displaying frames, in order to avoid a backlog."""

        metadata = dict(dtype=str(image.dtype), shape=image.shape)

        self.image_socket.send_json(metadata, zmq.SNDMORE)
        self.image_socket.send(image, copy=False)

        response = self.image_socket.recv()
        assert response == b'ok', response

    def transition_to_buffered(self, device_name, h5_filepath, initial_values, fresh):



        with h5py.File(h5_filepath, 'r') as f:
            group = f['devices'][self.device_name]
            if not 'EXPOSURES' in group:
                self.n_images = 0
                return {}

            self.h5_filepath = h5_filepath
            self.exposures = group['EXPOSURES'][:]
            self.logger.error(len(self.exposures))
            self.n_images = len(self.exposures)

            for exposure in self.exposures:
                if exposure[2].decode('utf-8') == "rearrange":
                    self.for_rearrange.append(True)
                else:
                    self.for_rearrange.append(False)
            
            self.logger.error(self.for_rearrange)


        self.fetch_image_finished.clear()

        if self.rearrange_active:
            self.shm_count[0] = -1  

        if self.dcam.buf_alloc(self.n_images):

            self.acquisition_thread = threading.Thread(
            target=self.fetch_n_images,
            args=(),
            daemon=True,
            )

            self.acquisition_thread.start()

            self.logger.error('thread started')
            return {}
        else:
            self.logger.error('-NG: Dcam.buf_alloc() fails with error {}'.format(self.dcam.lasterr()))
            return {}

    def transition_to_manual(self):

        if self.n_images == 0:
            assert self.acquisition_thread is None
            self.fetch_image_finished.set()
        else:
            assert self.acquisition_thread is not None

            if self.fetch_image_finished.wait(self.stop_acquisition_timeout): #waits for a duration of self.stop_acquisition_timeout for the self.fetch_image_finished Event to be set, which occurs only after all images have been fetched and appended to self.images
                self.fetch_image_finished.clear()
                self.dcam.buf_release()
            else:

                emsg = ("Acquisition thread did not finish. Likely did not acquire expected"
                        "number of images. Check triggering is connected/configured correctly.")

                self.logger.error(self.dcam.lasterr())
                self.dcam.cap_stop()
                self.abort()
                raise RuntimeError(emsg)
            
            self.acquisition_thread = None

            with h5py.File(self.h5_filepath, 'r+') as f:

                self.logger.error(self.h5_filepath)
                image_path = 'images/' + self.device_name
                image_group = f.require_group(image_path)
                image_group.attrs['camera'] = self.device_name

                labscript_utils.properties.set_attributes(image_group, self.attr_dict)

                # Whether we failed to get all the expected exposures:
                image_group.attrs['failed_shot'] = len(self.images) != len(self.exposures)

                # key the images by name and frametype. Allow for the case of there being
                # multiple images with the same name and frametype. In this case we will
                # save an array of images in a single dataset.
                images = {
                    (exposure['name'], exposure['frametype']): []
                    for exposure in self.exposures
                }

                # Iterate over expected exposures, sorted by acquisition time, to match them
                # up with the acquired images:
                self.exposures.sort(order='t')
                for image, exposure in zip(self.images, self.exposures):
                    images[(exposure['name'], exposure['frametype'])].append(image)

                # Save images to the HDF5 file:
                for (name, frametype), imagelist in images.items():
                    data = imagelist[0] if len(imagelist) == 1 else np.array(imagelist)
                    group = image_group.require_group(name)
                    dset = group.create_dataset(
                        frametype, data=data.astype('uint16'), dtype='uint16', compression='gzip'
                    )
                    # Specify this dataset should be viewed as an image
                    dset.attrs['CLASS'] = np.bytes_('IMAGE')
                    dset.attrs['IMAGE_SUBCLASS'] = np.bytes_('IMAGE_GRAYSCALE')

            try:
                image_block = np.stack(self.images)
                self._send_image_to_parent(image_block)
            except ValueError:
                raise ValueError("Cannot display images in the GUI, they are not all the same shape")
            else:
                self._send_image_to_parent(image_block)

            self.images = []
            self.n_images = None
            self.exposures = None
            self.h5_filepath = None
            if self.rearrange_active:
                self.shm_count[0] = -1
            self.for_rearrange = []

        return True
    
    def abort(self):

        self.dcam.buf_release()
        self.images = []
        self.n_images = None
        self.exposures = None
        self.acquisition_thread = None
        self.h5_filepath = None

        return True

    def abort_buffered(self):
        return self.abort()

    def abort_transition_to_buffered(self):
        return self.abort()

    def program_manual(self, values):
        return {}

    def shutdown(self):
        self.image_socket.close()  # forgetting to close the socket will crash blacs when restarting worker
        self.dcam.cap_stop()
        self.dcam.buf_release()
        self.dcam.dev_close()
        Dcamapi.uninit()



