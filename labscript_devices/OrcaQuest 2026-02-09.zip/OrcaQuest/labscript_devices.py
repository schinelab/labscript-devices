import sys
from labscript_utils import dedent
from labscript import TriggerableDevice, set_passed_properties
import numpy as np
import h5py

class OrcaQuest(TriggerableDevice):
    description = 'Hamamatsu OrcaQuest 2 Camera'
    
    @set_passed_properties(
        property_names={
            "device_properties": [ #available property tables with possible values can be found in the SDK files, >dcamsdk4>doc>cameraproperties>propC15550-22UP_en
                "trigger_source",
                "attr_dict",
                "rearrange_active",
                "stop_acquisition_timeout" #How long, in s, to wait after the shot finishes for the acquisition of images to complete before giving up.         
            ],
        }
    )
    def __init__( #parameters with default values don't need to be specified in the connection table
        self,
        name,
        parent_device,
        connection,
        serial_number,
        trigger_source,
        attr_dict,
        rearrange_active=False,
        stop_acquisition_timeout=2.0,
        **kwargs
    ):

        self.BLACS_connection = serial_number
        self.trigger_source = trigger_source
        self.stop_acquisition_timeout = stop_acquisition_timeout
        self.attr_dict = attr_dict
        self.rearrange_active = rearrange_active
        self.exposures = []

        TriggerableDevice.__init__(self, name, parent_device, connection, **kwargs)

    def expose(self, t, name, frametype='frame', trigger_duration=0.001):
        """Request an exposure at the given time. A trigger will be produced by the
        parent trigger object, with duration trigger_duration, or if not specified, of
        self.trigger_duration. The frame should have a `name, and optionally a
        `frametype`, both strings. These determine where the image will be stored in the
        hdf5 file. `name` should be a description of the image being taken, such as
        "insitu_absorption" or "fluorescence" or similar. `frametype` is optional and is
        the type of frame being acquired, for imaging methods that involve multiple
        frames. For example an absorption image of atoms might have three frames:
        'probe', 'atoms' and 'background'. For this one might call expose three times
        with the same name, but three different frametypes.
        """
        #consecutive exposures should not be scheduled closer together than the trigger duration

        # Backward compatibility with code that calls expose with name as the first
        # argument and t as the second argument:
        if isinstance(t, str) and isinstance(name, (int, float)):
            msg = """expose() takes `t` as the first argument and `name` as the second
                argument, but was called with a string as the first argument and a
                number as the second. Swapping arguments for compatibility, but you are
                advised to modify your code to the correct argument order."""
            print(dedent(msg), file=sys.stderr)
            t, name = name, t
        if not trigger_duration > 0:
            msg = "trigger_duration must be > 0, not %s" % str(trigger_duration)
            raise ValueError(msg)
        self.trigger(t, trigger_duration)
        self.exposures.append((t, name, frametype, trigger_duration))
        return trigger_duration

    def generate_code(self, hdf5_file):
        self.do_checks()
        vlenstr = h5py.special_dtype(vlen=str)
        table_dtypes = [
            ('t', float),
            ('name', vlenstr),
            ('frametype', vlenstr),
            ('trigger_duration', float),
        ]
        data = np.array(self.exposures, dtype=table_dtypes)
        group = self.init_device_group(hdf5_file)
        if self.exposures:
            group.create_dataset('EXPOSURES', data=data)

        