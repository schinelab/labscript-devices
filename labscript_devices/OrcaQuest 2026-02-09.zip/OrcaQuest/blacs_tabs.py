import os
import json
import time
import ast
import zmq
import threading

import labscript_utils.h5_lock
import h5py

import numpy as np

import qtutils.icons
from qtutils.qt import QtWidgets, QtGui, QtCore

from blacs.tab_base_classes import define_state, MODE_MANUAL
from blacs.device_base_class import DeviceTab

import labscript_utils.properties

from .orca_widget import OrcaWidget

class OrcaQuestTab(DeviceTab):
    # Subclasses may override this if all they do is replace the worker class with a
    # different one:
    worker_class = 'labscript_devices.OrcaQuest.blacs_workers.OrcaQuestWorker' 
    # Subclasses may override this to False if camera attributes should be set every
    # shot even if the same values have previously been set:
    use_smart_programming = True

    def initialise_GUI(self):
        layout = self.get_tab_layout()

        self.widget = OrcaWidget(layout.parentWidget(), self.device_name)

        layout.addWidget(self.widget)

        self.acquiring = False

        self.supports_smart_programming(self.use_smart_programming)

        self.zmq_ctx = zmq.Context()
        self.image_socket = self.zmq_ctx.socket(zmq.REP)
        self.image_socket_port = self.image_socket.bind_to_random_port('tcp://*', min_port=50000, max_port=59999, max_tries=100)

        self.image_recv_thread = threading.Thread(target=self.image_recv_handler, daemon=True)
        self.image_recv_thread.start()

    def initialise_workers(self):
        table = self.settings['connection_table']
        connection_table_properties = table.find_by_name(self.device_name).properties
        # The device properties can vary on a shot-by-shot basis, but at startup we will
        # initially set the values that are configured in the connection table, so they
        # can be used for manual mode acquisition:
        with h5py.File(table.filepath, 'r') as f:
            device_properties = labscript_utils.properties.get(
                f, self.device_name, "device_properties"
            )
            
        worker_initialisation_kwargs = {
            'trigger_source': device_properties['trigger_source'],
            'attr_dict': device_properties['attr_dict'],
            'rearrange_active': device_properties['rearrange_active'],
            'stop_acquisition_timeout': device_properties['stop_acquisition_timeout'],
            'image_receiver_port': self.image_socket_port
        }
        self.create_worker(
            'main_worker', self.worker_class, worker_initialisation_kwargs
        )
        self.primary_worker = "main_worker"

    def image_recv_handler(self):
        while True:
            # Acknowledge immediately so that the worker process can begin acquiring the
            # next frame. This increases the possible frame rate since we may render a frame
            # whilst acquiring the next, but does not allow us to accumulate a backlog since
            # only one call to this method may occur at a time.
            md_json, image_data = self.image_socket.recv_multipart()

            self.image_socket.send(b'ok')

            md = json.loads(md_json)
            image = np.frombuffer(memoryview(image_data), dtype=md['dtype'])

            image = image.reshape(md['shape'])
            if len(image.shape) == 3 and image.shape[0] == 1:
                # If only one image given as a 3D array, convert to 2D array:
                image = image.reshape(image.shape[1:])

            self.widget.request_update_image.emit(image)