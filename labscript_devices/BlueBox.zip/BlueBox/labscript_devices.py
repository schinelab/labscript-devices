import numpy as np
from labscript import Device, StaticDDS, StaticAnalogQuantity, StaticDigitalOut, set_passed_properties
import labscript_utils.h5_lock
import h5py

class BlueBoxDDS(StaticDDS):

    description = 'Multichromatic DDS'
    allowed_children = [StaticAnalogQuantity,StaticDigitalOut]
    generation = 2
    
    @set_passed_properties()    
    def __init__(self, 
        name, 
        parent_device, 
        connection, 
        freq_limits = None, 
        freq_conv_class = None,
        freq_conv_params = {},
        amp_limits = None, 
        amp_conv_class = None,
        amp_conv_params = {}, 
        phase_limits = None, 
        phase_conv_class = None,
        phase_conv_params = {}
    ):
        Device.__init__(self,name,parent_device,connection)

        self.freqlist = [] #stores ordered list of frequencies for all instances and all channels in a single 1D array
        self.amplist = []
        self.phaselist = []
        self.gatelist = []
        
        for i in range(self.parent_device.num_instances):
            for j in range(self.parent_device.channels_per_instance[i]):
                output_name = f'inst{i}_chan{j}'
                freq = StaticAnalogQuantity(self.name+'_'+output_name+'_freq',self,output_name+'_freq',freq_limits,freq_conv_class,freq_conv_params) #StaticAnalogQuantity(name, parent_device, connection)
                self.freqlist.append(freq)
                amp = StaticAnalogQuantity(self.name+'_'+output_name+'_amp',self,output_name+'_amp',amp_limits,amp_conv_class,amp_conv_params)
                self.amplist.append(amp)
                phase = StaticAnalogQuantity(self.name+'_'+output_name+'_phase',self,output_name+'_phase',phase_limits,phase_conv_class,phase_conv_params)
                self.phaselist.append(phase)
                gate = StaticDigitalOut(self.name+'_'+output_name+'_gate',self,output_name+'_gate')
                self.gatelist.append(gate)

    def setfreq(self, instance, channel, value, units=None): #instance and channel being zero-indexed, value in MHz
        index = 0
        for i in range(instance):
            index += self.parent_device.channels_per_instance[i]
        index += channel
        self.freqlist[index].constant(value,units)
        
    def setamp(self, instance, channel, value, units=None): #instance and channel being zero-indexed
        index = 0
        for i in range(instance):
            index += self.parent_device.channels_per_instance[i]
        index += channel
        self.amplist[index].constant(value,units)

    def setphase(self, instance, channel, value, units=None): #instance and channel being zero-indexed
        index = 0
        for i in range(instance):
            index += self.parent_device.channels_per_instance[i]
        index += channel
        self.phaselist[index].constant(value,units)
            
    def enable(self, instance, channel):
        index = 0
        for i in range(instance):
            index += self.parent_device.channels_per_instance[i]
        index += channel
        self.gatelist[index].go_high() #sets the gate raw_output to 1
                            
    def disable(self, instance, channel):
        index = 0
        for i in range(instance):
            index += self.parent_device.channels_per_instance[i]
        index += channel
        self.gatelist[index].go_low() #sets the gate raw_output to 0
    
class BlueBox(Device):
    # A custom multichromatic DDS used to generate optical tweezers
    description = 'Multichromatic DDS Box'
    allowed_children = [BlueBoxDDS]
    generation = 0

    @set_passed_properties(
        property_names={
            "connection_table_properties": [
                "build_path",
                "vivado_path",
                "startup_script",
                "dac_config",
                "ip",
                "udp"
            ],
            "device_properties": [
                "frequency_scale_factor",
                "amplitude_scale_factor",
                "phase_scale_factor",
                "num_instances",
                "channels_per_instance"
            ]            
        }
    )
    def __init__(
        self,
        name,
        com_port,
        build_path,
        vivado_path,
        startup_script,
        dac_config,
        ip,
        udp
    ):
        Device.__init__(self, name, None, None)
        self.BLACS_connection = com_port
        self.build_path = build_path
        self.vivado_path = vivado_path
        self.startup_script = startup_script
        self.dac_config = dac_config
        self.ip = ip
        self.udp = udp
        self.frequency_scale_factor = 2**32/614.4
        self.amplitude_scale_factor = 2**16-1
        self.phase_scale_factor = (2**18-1)/360
        self.num_instances = 4
        self.channels_per_instance = [64,64,32,32]
        self.channel_outputs = []


    def generate_code(self, hdf5_file):
        
        group = self.init_device_group(hdf5_file)

        table_dtypes = [
            ('freq', float),
            ('amp', float),
            ('phase', float),
            ('clrstate', int)
        ]

        multidds = self.child_devices[0]

        index = 0

        for i in range(self.num_instances):
            self.channel_outputs = []

            for j in range(self.channels_per_instance[i]):
                frequency = multidds.freqlist[index]
                if frequency._static_value is None:
                    frequency.constant(0) #sets freq/amp/phase/gate to 0 by default
                amplitude = multidds.amplist[index]
                if amplitude._static_value is None:
                    amplitude.constant(0)               
                phase = multidds.phaselist[index]
                if phase._static_value is None:
                    phase.constant(0)  
                gate = multidds.gatelist[index]
                if gate._static_value is None:
                    gate.go_low() 

                ignore = frequency.get_change_times()
                frequency.make_timeseries([])
                frequency.expand_timeseries()

                ignore = amplitude.get_change_times()
                amplitude.make_timeseries([])
                amplitude.expand_timeseries()

                ignore = phase.get_change_times()
                phase.make_timeseries([])
                phase.expand_timeseries()
                
                ignore = gate.get_change_times()
                gate.make_timeseries([])
                gate.expand_timeseries()

                #upon full completion of the inner loop, will be a fully populated array of channel outputs for a single instance, then gets erased and moves on to the next instance
                self.channel_outputs.append((frequency.raw_output[0], amplitude.raw_output[0], phase.raw_output[0], gate.raw_output[0]))

                index += 1


            data = np.array(self.channel_outputs, dtype=table_dtypes)

            group.create_dataset(f"core{i}", data=data)

            #process the freq, amp, phase, gate of each channel (StaticAnalogQuantity) 
            #and save them to an ordered (array index corresponding to the channel number) nparray of 64 tuples, each tuple representing the outputs of a single channel
            #which then gets saved as the corresponding instance dataset of the shot file (in non-lsb units for readability, gets converted to lsb in blacs_workers)


        #raw_output of a StaticAnalogQuantity/StaticDigitalOut is set to an array with a single element equal to its constant output value



