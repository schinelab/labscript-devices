import numpy as np
import labscript_utils.h5_lock
import h5py
from blacs.tab_base_classes import Worker
from labscript import LabscriptError

import sys
import os
import logging
from zprocess import RichStreamHandler
import zprocess

class BlueBoxWorker(Worker):
    # additional properties passed down by the initialise_workers() method in blacs_tabs.py
    # - build_path
    # - vivado_path
    # - startup_script
    # - dac_config
    # - ip
    # - udp
    # - frequency_scale_factor
    # - amplitude_scale_factor
    # - phase_scale_factor
    # - num_instances
    # - channels_per_instance
    def init(self):


        self.logger = logging.getLogger("bluebox")
        self.logger.setLevel(logging.DEBUG)

        # Prevent duplicate handlers if this code runs more than once
        if not self.logger.handlers:
            self.logger.addHandler(RichStreamHandler())

        # Now use it in your code
        self.logger.error("Worker started")

        #opens up communication with the box, but user still needs to manually connect to the box using Vivado
        sys.path.append(os.path.join(os.path.dirname(__file__), self.build_path))
        from lbus_access import lbus_access
        from lbus_csr import Csr_Lbus
        from multi_tone_controller import MultiToneController
        #from fvseei.move_tone_sequencer_example import reset_synthesizer

        cmd1 = self.vivado_path
        cmd2 = r"venv\Scripts\activate.bat" #activate virtual environment
        cmd3 = "python " + self.startup_script
        cmd4 = self.dac_config
        os.system(cmd1+" && "+cmd2+" && "+cmd3+" && "+cmd4)

        chip = lbus_access(self.ip, timeout=1.02, port=self.udp, allow_burst=False)
        self.csr = Csr_Lbus(chip)

        self.tone_controllers = []
        for i in range(self.num_instances):
            controller = MultiToneController(self.csr, dds_index=i)
            self.tone_controllers.append(controller)
            self.logger.info(f"Initialized MultiToneController for DDS instance {i}")

    def freq_to_lsb(self, freq): #frequency in MHz

        #if freq > 270:
            #raise LabscriptError("Too close to the Nyquist frequency. Please enter a frequency less than or equal to 270 MHz.")
        freq = np.round(self.frequency_scale_factor*freq).astype(int) #rounds off converted lsb to nearest integer
        return freq

    def amp_to_lsb(self, amp): #max amplitude = 1

        if amp > 1:
            raise LabscriptError("Max amplitude is 1. Please enter an amplitude less than or equal to 1.")
        amp = np.round(self.amplitude_scale_factor*amp).astype(int)
        return amp

    def phase_to_lsb(self, phase): #phase in degrees

        phase = np.round(self.phase_scale_factor*phase).astype(int) 
        return phase

    def write_register(self, instance, channel, value, csr, register_type):
        method_name = f"ddsctrl{instance}_{register_type}_{channel}_write"
        method = getattr(csr, method_name, None)
        if method:
            method(value)
        else:
            print(f"Method {method_name} not found.")

    def transition_to_buffered(self,device_name,h5file,initial_values,fresh):
        self.initial_values = initial_values
        self.final_values = {}

        with h5py.File(h5file, 'r') as hdf5_file:
            group = hdf5_file['/devices/'+device_name]

            for i,dset in enumerate(group.values()): #enumerate these two loops to then pass the correct channel and instance number i and channel number j into write_register
                controller = self.tone_controllers[i]
                controller.reset()

                for j,outputs in enumerate(dset):
                    freq, amp, phase, gate = outputs
                    self.logger.info(outputs)

                    if gate == 1:
                        controller.set_tone(j,freq,amp,phase) #the set_tone method automatically removes the clear on the channel it is setting
                    if gate == 0:
                        controller.set_tone(j,freq,amp,phase)
                        self.write_register(i,j,1,self.csr,"clr") #manually re-clears the channel, since set_tone automatically removes the clear

                    # freqlsb = self.freq_to_lsb(freq) # write_register() should do everything starting from this line, except for the lines we are moving outside the loop
                    # amplsb = self.amp_to_lsb(amp)
                    # phaselsb = self.phase_to_lsb(phase)

                    # self.write_register(i,j,1-gate,self.csr,"clr")
                    # self.write_register(i,j,freqlsb,self.csr,"ftw")
                    # self.write_register(i,j,amplsb,self.csr,"atw")
                    # self.write_register(i,j,phaselsb,self.csr,"ptw")

                    #dictionary of dictionaries, for now we just integrate the instance 0 channel 0 DDS in with the GUI
                    if i==0 and j==0:
                        final_values = {'dds 0':{}} #should match the name of the corresponding output objects placed in the dds BLACS UI widgets, pushes these values into the widgets
                        
                        final_values['dds 0']['freq'] = np.round(freq)
                        final_values['dds 0']['amp'] = np.round(amp)
                        final_values['dds 0']['phase'] = np.round(phase)
                        final_values['dds 0']['gate'] = gate

                method = getattr(self.csr, f"ddsctrl{i}_syncddsstatic_write", None)
                method(1)                

            method = getattr(self.csr, "dac_global_clr_write", None)
            method(0)  
 
        return final_values

    def check_remote_values(self): #when we add more channels, will have to loop through the datasets (instance) and dataset elements (channels) by reading the shot h5 file, just like in transition_to_buffered()

        results = {'dds 0':{}}

        method = getattr(self.csr, "ddsctrl0_ftw_0_read", None)
        freq = method() #in lsb
        freq = np.round(freq/self.frequency_scale_factor)
        method = getattr(self.csr, "ddsctrl0_atw_0_read", None)
        amp = method()
        amp = np.round(amp/self.amplitude_scale_factor)
        method = getattr(self.csr, "ddsctrl0_ptw_0_read", None)
        phase = method()
        phase = np.round(phase/self.phase_scale_factor)
        method = getattr(self.csr, "ddsctrl0_clr_0_read", None)
        gate = 1-method()

        results['dds 0']['freq'] = freq
        results['dds 0']['amp'] = amp
        results['dds 0']['phase'] = phase
        results['dds 0']['gate'] = gate

        #can try converting into natural units but only if we also "reconvert" the lsb values in transition_to_buffered()

        return results

    def program_manual(self,front_panel_values): #must modify for more channels and add for loops to loop through front_panel_values, don't know yet if we're gonna have 64*4 separate DDS widgets or how to display them
        freq = front_panel_values['dds 0']['freq']
        amp = front_panel_values['dds 0']['amp']
        phase = front_panel_values['dds 0']['phase']
        gate = front_panel_values['dds 0']['gate']
                                        # in the future we want the GUI values to be in natural units?
        controller = self.tone_controllers[0]

        method = getattr(self.csr, "dac_global_clr_write", None)
        method(1)
        if gate == 1:
                        controller.set_tone(0,freq,amp,phase)

        method = getattr(self.csr, "ddsctrl0_syncddsstatic_write", None)
        method(1)
        method = getattr(self.csr, "dac_global_clr_write", None)
        method(0)  

        return self.check_remote_values()

    def abort_transition_to_buffered(self):
        return self.transition_to_manual(True)
        
    def abort_buffered(self):
        return self.transition_to_manual(True)
    
    def transition_to_manual(self,abort = False):
        if abort:
            # If we're aborting the run, reset to original value
            self.program_manual(self.initial_values)
        # If we're not aborting the run, stick with buffered value. Nothing to do really!
        # return the current values in the device
        return True