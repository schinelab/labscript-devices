from blacs.device_base_class import DeviceTab
import h5py
import labscript_utils.properties

class BlueBoxTab(DeviceTab):

    def initialise_GUI(self):

        dds_prop = {'dds 0':{'freq':{'base_unit':   'lsb',
                                     'min':         0,
                                     'max':         1e10,
                                     'step':        1e6,
                                     'decimals':    3},
                             'amp':{'base_unit':   'lsb',
                                     'min':         0,
                                     'max':         1e5,
                                     'step':        100,
                                     'decimals':    3},
                             'phase':{'base_unit':   'lsb',
                                     'min':         0,
                                     'max':         1e6,
                                     'step':        1000,
                                     'decimals':    3},
                             'gate':{}
                                 }
                                 }

        self.create_dds_outputs(dds_prop)        
        # Create widgets for output objects
        dds_widgets,_,_ = self.auto_create_widgets()
        # and auto place the widgets in the UI
        self.auto_place_widgets(("DDS Outputs",dds_widgets))

        self.supports_remote_value_check(True)
        self.supports_smart_programming(False) 

    def initialise_workers(self):
        table = self.settings['connection_table']
        connection_table_properties = table.find_by_name(self.device_name).properties
        with h5py.File(table.filepath, 'r') as f:
            device_properties = labscript_utils.properties.get(
                f, self.device_name, "device_properties"
            )

        worker_initialisation_kwargs = {
            'build_path': connection_table_properties['build_path'],
            'vivado_path': connection_table_properties['vivado_path'],
            'startup_script': connection_table_properties['startup_script'],
            'dac_config': connection_table_properties['dac_config'],
            'ip': connection_table_properties['ip'],
            'udp': connection_table_properties['udp'],
            'frequency_scale_factor': device_properties['frequency_scale_factor'],
            'amplitude_scale_factor': device_properties['amplitude_scale_factor'],
            'phase_scale_factor': device_properties['phase_scale_factor'],
            'num_instances': device_properties['num_instances'],
            'channels_per_instance': device_properties['channels_per_instance']
        }
        self.create_worker(
            "main_worker", "labscript_devices.BlueBox.blacs_workers.BlueBoxWorker", worker_initialisation_kwargs
        )
        self.primary_worker = "main_worker"