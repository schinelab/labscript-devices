import numpy as np
import labscript_utils.h5_lock
import labscript_utils.properties
import h5py
from blacs.tab_base_classes import Worker
from .dcam import *
from .dcamapi4 import *
import zmq
import threading
import logging
from zprocess import RichStreamHandler

from labscript_utils.ls_zprocess import Context

class OrcaQuestWorker(Worker):
    # additional properties passed down by the initialise_workers() method in blacs_tabs.py
    # - parent_host
    # - trigger_source
    # - attr_dict
    # - stop_acquisition_timeout
    # - image_receiver_port

    def init(self):

        self.logger = logging.getLogger("bluebox")
        self.logger.setLevel(logging.DEBUG)

        # Prevent duplicate handlers if this code runs more than once
        if not self.logger.handlers:
            self.logger.addHandler(RichStreamHandler())

        # Now use it in your code
        self.logger.error("Worker started")

        if Dcamapi.init():
            device_index = 0 #hardcoded Hamamatsu device index, but can make into a connection table property in the future if we start using more than one Hamamatsu device
            self.dcam = Dcam(device_index)
            if self.dcam.dev_open():
                self.dcam.prop_setvalue(DCAM_IDPROP.TRIGGERSOURCE, self.trigger_source)
                for key in self.attr_dict:
                    self.dcam.prop_setvalue(getattr(DCAM_IDPROP,key,None), self.attr_dict[key])

            else:
                self.logger.error('-NG: Dcam.dev_open() fails with error {}'.format(self.dcam.lasterr()))
        else:
            self.logger.error('-NG: Dcamapi.init() fails with error {}'.format(Dcamapi.lasterr()))

        self.images = []
        self.n_images = None

        self.exposures = None
        self.acquisition_thread = None
        self.h5_filepath = None

        self.fetch_image_finished = threading.Event()

        self.zmq_context = zmq.Context()

        self.image_socket = self.zmq_context.socket(zmq.REQ)
        self.image_socket.connect(
            f'tcp://{self.parent_host}:{self.image_receiver_port}'
        )

    def fetch_n_images(self):
        poll_timeout = 1 #polls in intervals of 1 ms, could this be longer?
        if self.dcam.cap_snapshot():
            for i in range(self.n_images):
                self.logger.error('looking for image'+str(i))
                self.logger.error('status 0: {}'.format(self.dcam.cap_status()))
                while True:
                    if self.dcam.wait_capevent_frameready(poll_timeout): #wait until the camera detects a capture event and then pulls from the buffer during the downtime of the main thread performing shot execution
                        data = self.dcam.buf_getlastframedata() #data in the form of 2d numpy array
                        self.logger.error('new capture acquired')
                        break
                    else:
                        dcamerr = self.dcam.lasterr()
                        if dcamerr.is_timeout():
                            continue
                        else:
                            self.logger.error('-NG: Dcam.wait_event() fails with error {}'.format(dcamerr))

                self.images.append(data)    
        else:
            print('-NG: Dcam.cap_start() fails with error {}'.format(self.dcam.lasterr()))

        self.fetch_image_finished.set() #for fetch_n_images(), call this method at the very end after the loop has fully completed and self.images is fully populated

    def _send_image_to_parent(self, image):
        """Send the image to the GUI to display. This will block if the parent process
        is lagging behind in displaying frames, in order to avoid a backlog."""

        metadata = dict(dtype=str(image.dtype), shape=image.shape)

        self.image_socket.send_json(metadata, zmq.SNDMORE)
        self.image_socket.send(image, copy=False)

        response = self.image_socket.recv()
        assert response == b'ok', response

    def transition_to_buffered(self, device_name, h5_filepath, initial_values, fresh):

        with h5py.File(h5_filepath, 'r') as f:
            group = f['devices'][self.device_name]
            if not 'EXPOSURES' in group:
                return {}

            self.h5_filepath = h5_filepath
            self.exposures = group['EXPOSURES'][:]
            self.n_images = len(self.exposures)

        self.fetch_image_finished.clear()

        if self.dcam.buf_alloc(self.n_images):

            self.logger.error('status 3: {}'.format(self.dcam.cap_status()))

            self.acquisition_thread = threading.Thread(
            target=self.fetch_n_images,
            args=(),
            daemon=True,
            )

            self.acquisition_thread.start()

            self.logger.error('thread started')
            return {}
        else:
            self.logger.error('-NG: Dcam.buf_alloc() fails with error {}'.format(self.dcam.lasterr()))
            return {}

    def transition_to_manual(self):

        assert self.acquisition_thread is not None

        if self.fetch_image_finished.wait(self.stop_acquisition_timeout): #waits for a duration of self.stop_acquisition_timeout for the self.fetch_image_finished Event to be set, which occurs only after all images have been fetched and appended to self.images
            self.fetch_image_finished.clear()
            self.dcam.buf_release()
        else:

            emsg = ("Acquisition thread did not finish. Likely did not acquire expected"
                    "number of images. Check triggering is connected/configured correctly.")

            self.logger.error(self.dcam.lasterr())
            self.dcam.cap_stop()
            self.abort()
            raise RuntimeError(emsg)
        
        self.acquisition_thread = None

        with h5py.File(self.h5_filepath, 'r+') as f:

            self.logger.error(self.h5_filepath)
            image_path = 'images/' + self.device_name
            image_group = f.require_group(image_path)
            image_group.attrs['camera'] = self.device_name

            labscript_utils.properties.set_attributes(image_group, self.attr_dict)

            # Whether we failed to get all the expected exposures:
            image_group.attrs['failed_shot'] = len(self.images) != len(self.exposures)

            # key the images by name and frametype. Allow for the case of there being
            # multiple images with the same name and frametype. In this case we will
            # save an array of images in a single dataset.
            images = {
                (exposure['name'], exposure['frametype']): []
                for exposure in self.exposures
            }

            # Iterate over expected exposures, sorted by acquisition time, to match them
            # up with the acquired images:
            self.exposures.sort(order='t')
            for image, exposure in zip(self.images, self.exposures):
                images[(exposure['name'], exposure['frametype'])].append(image)

            # Save images to the HDF5 file:
            for (name, frametype), imagelist in images.items():
                data = imagelist[0] if len(imagelist) == 1 else np.array(imagelist)
                group = image_group.require_group(name)
                dset = group.create_dataset(
                    frametype, data=data.astype('uint16'), dtype='uint16', compression='gzip'
                )
                # Specify this dataset should be viewed as an image
                dset.attrs['CLASS'] = np.bytes_('IMAGE')
                dset.attrs['IMAGE_SUBCLASS'] = np.bytes_('IMAGE_GRAYSCALE')

        try:
            image_block = np.stack(self.images)
        except ValueError:
            raise ValueError("Cannot display images in the GUI, they are not all the same shape")
        else:
            self._send_image_to_parent(image_block)

        self.images = []
        self.n_images = None
        self.exposures = None
        self.h5_filepath = None

        return True
    
    def abort(self):

        self.dcam.buf_release()
        self.images = []
        self.n_images = None
        self.exposures = None
        self.acquisition_thread = None
        self.h5_filepath = None

        return True

    def abort_buffered(self):
        return self.abort()

    def abort_transition_to_buffered(self):
        return self.abort()

    def program_manual(self, values):
        return {}

    def shutdown(self):
        self.image_socket.close()  # forgetting to close the socket will crash blacs when restarting worker
        self.dcam.cap_stop()
        self.dcam.buf_release()
        self.dcam.dev_close()
        Dcamapi.uninit()



