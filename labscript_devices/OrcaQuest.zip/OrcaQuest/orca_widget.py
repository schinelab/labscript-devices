import os
import qtutils.icons

from PyQt5 import uic, QtWidgets, QtCore
from PyQt5.QtCore import pyqtSignal

import pyqtgraph as pg


class OrcaWidget(QtWidgets.QWidget):
    # signals emitted by this widget to outside world
    on_continuous_requested = pyqtSignal()
    on_stop_requested = pyqtSignal()
    on_snap_requested = pyqtSignal()
    on_continuous_max_change_requested = pyqtSignal(float)

    # signals this widget received
    request_update_colormap = pyqtSignal(object)
    request_update_image = pyqtSignal(object)
    request_update_fps = pyqtSignal(float)
    request_update_max_fps = pyqtSignal(float)

    def __init__(self, parent, device_name):
        super().__init__(parent)

        self.device_name = device_name

        ui_filepath = os.path.join(
            os.path.dirname(os.path.realpath(__file__)), 'blacs_tab.ui'
        )

        uic.loadUi(ui_filepath, self)

        self.image = pg.ImageView()
        self.image.setSizePolicy(
            QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding
        )
        self.horizontalLayout.addWidget(self.image)

        self.request_update_image.connect(self.update_image)

        # Ensure the GUI reserves space for these widgets even if they are hidden.
        # This prevents the GUI jumping around when buttons are clicked:
        for widget in [
            self.stopButton,
            self.maxRateSpinBox,
            self.noMaxButton,
        ]:
            size_policy = widget.sizePolicy()
            if hasattr(size_policy, 'setRetainSizeWhenHidden'): # Qt 5.2+ only
                size_policy.setRetainSizeWhenHidden(True)
                widget.setSizePolicy(size_policy)

    def update_image(self, image):
        if self.image.image is None:
            self.image.setImage(image.swapaxes(-1, -2))
        else:
            self.image.setImage(
                image.swapaxes(-1, -2), autoRange=False, autoLevels=False
            )

        # draw immediately
        QtWidgets.QApplication.instance().sendPostedEvents()

